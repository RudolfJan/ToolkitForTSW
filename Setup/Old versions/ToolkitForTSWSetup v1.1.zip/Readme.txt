ToolkitForTSW

ToolkitForTSW is a toolkit for Train Simulator World.
At present it has limited functionality, but this will increase over time.
After installation, please set up the program options before trying to do anything else.

Check out https:/www.hollandhiking.nl/trainsimulator for other tools and documentation for TSW and TrainSimulator.

Contact the author using trainsimulator@hollandhiking.nl

Installation instructions:
- Use the installer to install all tools
- You will need to download additional free tools
- Make sure to set all required options
- You need to specify a location for the data files during the install process. If you specify another location than for a previous version, your datafiles will NOT be copied automatically to the new location.

See the manual for details. You can find the manual in the ToolkitForTSW data folder.

Version history:

Version 1.1:
- Added removal tool for ntro videos
- Options settings improved
- Mod installer and manager improved

Version 1.0:
- Support for Epic Games Platform
- Splash screen
- New Rush Hour edition settings
- Error popup window

Version 0.9:
- Automatic backups
- Experimental settings
- Revised RouteGuides window
- Bug fixes and refactoring

Version 08:
- Screenshot manager totally revised

Version 0.71
- Fixed an issue with the installation procedure

Version 0.7:
- Added Scenario Editor
- Updated Mod tool
- Bug fixes

Version 0.6:
- Application renamed to ToolkitForTSW
- Now supports TSW2 only
- Added Scenario manager tool
- Settings tool improved and added new TSW2 settings.
